# Các bước đóng góp vào repo

1. Fork repo

<img width="541" alt="Screen Shot 2022-05-19 at 18 09 56" src="https://user-images.githubusercontent.com/44517986/169280093-fc98068a-d80c-4e61-b069-20be0ed855f5.png">

2. Tạo branch trong repo đã fork
3. Edit code
4. Push lên repo của bạn
5. Tạo pull request với repo đã fork vào repo này

<img width="1254" alt="Screen Shot 2022-05-19 at 18 07 03" src="https://user-images.githubusercontent.com/44517986/169279960-974d7abf-0b02-4db1-97a5-6dbeedca905f.png">

6. Vầy là xong hihi