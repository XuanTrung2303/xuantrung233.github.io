export interface SvgProps {
  setColor: string
  setWidth: string
  setHeight: string
}
